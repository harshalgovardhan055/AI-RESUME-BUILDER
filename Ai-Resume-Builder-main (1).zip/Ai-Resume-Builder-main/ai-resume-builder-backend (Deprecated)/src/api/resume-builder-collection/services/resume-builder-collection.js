'use strict';

/**
 * resume-builder-collection service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::resume-builder-collection.resume-builder-collection');
